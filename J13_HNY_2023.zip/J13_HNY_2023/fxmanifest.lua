fx_version 'bodacious'
game 'gta5'

author 'J0KER'
description '2023 Happy New Year'
version '1.0.0'

this_is_a_map 'yes'